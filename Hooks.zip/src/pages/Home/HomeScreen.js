import React, { Component } from 'react';
import '../artikel/Artikel.css'

const HomeScreen = () => {
    return (
        <div>
            <h3><center>Welcome To Home Page</center></h3><br />
        </div>
    );
}

export default HomeScreen;