import axios from 'axios'

const getArtikel = async function(){
    let artikel = await axios.get("http://localhost:3000/Artikel")
    return artikel
}
const createArtikel = async (form)=>{
    const artikel = await fetch("http://localhost:3000/Artikel", {
        method:"POST",
        headers:{
            Accept:'application/json','Content-Type':'application/json'
        },
        body : JSON.stringify(form)
    })
    return await artikel.json()
}
export {getArtikel,createArtikel}