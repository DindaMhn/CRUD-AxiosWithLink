import React, { Component } from 'react';
import './Artikel.css'

class ArtikelList extends Component {
    render() {
        let { artikel, message } = this.props
        let allResult = artikel.map((data) =>
            <tr>
                <td>{data.id_user}</td>
                <td>{data.id_artikel}</td>
                <td>{data.user_name}</td>
                <td>{data.title}</td>
                <td>{data.category_name}</td>
                <td>{data.description}</td>
                <td>{data.date}</td>
                <td><strong>{message}</strong></td>
            </tr>)
        return (
            <div className="container">
                <h3>Data</h3>
                <div>
                    <table>
                        <thead>
                            <tr>
                                <th>ID User</th>
                                <th>ID Artikel</th>
                                <th>Username</th>
                                <th>Title</th>
                                <th>Category Name</th>
                                <th>Description</th>
                                <th>Date</th>
                                <th>Message</th>
                            </tr>
                        </thead>
                        <tbody>
                            {allResult}
                        </tbody>
                    </table>
                </div>

            </div>
        );
    }
}

export default ArtikelList;