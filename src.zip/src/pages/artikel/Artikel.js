import React, { Component } from 'react';
import ArtikelList from './ArtikelList'
import { createArtikel, getArtikel } from '../../api/artikel/artikel';
import './Artikel.css'

class Artikel extends Component {
    state = {
        id_artikel: "",
        id_user: "",
        title: "",
        description: "",
        date: "",
        id_category: "",
        artikel: [],
        message: "",
        isCreated: false,
        onHomeScreen: false,
        onArtikel: false,
        onLogout:false,
        onUser:false
    }
    componentDidMount() {
        console.log("component did mount");
        getArtikel().then((artikel) => {
            this.setState({ ...this.state, artikel: artikel.data.data, message: artikel.data.message })
        }).catch((error) => {
            alert(error)
        })
    }
    loadData = () => {
        getArtikel().then((artikel) => {
            this.setState({ ...this.state, artikel: this.state.artikel, message: this.state.message })
        }).catch((error) => {
            alert(error)
        })
    }
    handleChangeInput = (event) => {
        let name = event.target.name
        this.setState({
            ...this.state,
            [name]: event.target.value
        })
    }
    addNewArtikel = () => {
        console.log(" add clicked");
        createArtikel({
            id_artikel: this.state.id_artikel,
            id_user: this.state.id_user,
            title: this.state.title,
            description: this.state.description,
            date: this.state.date,
            id_category: this.state.id_category
        })
        this.setState({
            isCreated: true
        })
        this.loadData()
    }
    // HomePage = ()=>{
    //     this.setState({
    //         onHomeScreen: true,
    //         onArtikel: false,
    //         onLogout:false,
    //         onUser:false
    //     })
    // }
    // LoginPage=()=>{
    //     this.setState({
    //         onHomeScreen: false,
    //         onArtikel: false,
    //         onLogout:true,
    //         onUser:false
    //     })
    // }
    // ArtikelPage = ()=>{
    //     this.setState({
    //         onHomeScreen: false,
    //         onArtikel: true,
    //         onLogout:false,
    //         onUser:false
    //     })
    // }
    // UserPage = ()=>{
    //     this.setState({
    //         onHomeScreen: false,
    //         onArtikel: false,
    //         onLogout:false,
    //         onUser:true
    //     })
    // }

    render() {
        // if (this.state.isCreated) {
        //     return (<Artikel />);
        // }
        // if(this.state.onHomeScreen){
        //     return(<HomeScreen/>)
        // }
        // if(this.state.onLogout){
        //     return(<LoginScreen/>)
        // }
        // if(this.state.onUser){
        //     return(<User/>)
        // }

        return (
            <div>
                {/* <nav className="navbar navbar-expand-lg">
                <ul className="navbar-nav">
                    <button className="nav-button" onClick={this.HomePage}>Home</button>
                    <button className="nav-button" onClick={this.ArtikelPage}>Artikel</button>
                        <button className="nav-button" onClick={this.UserPage}>User</button>
                    <button className="nav-button" onClick={this.LoginPage}>Logout</button>
                </ul>
                </nav> */}
                <ArtikelList message={this.state.message} artikel={this.state.artikel} update={this.updateNewArtikel} /><br/>
                <h3>CREATE ARTIKEL</h3>
                <input name="id_artikel" placeholder="Id Artikel" value={this.state.id_artikel} onChange={this.handleChangeInput} /><br />
                <input name="id_user" placeholder="Id User" value={this.state.id_user} onChange={this.handleChangeInput} /><br />
                <input name="title" placeholder="Title" value={this.state.title} onChange={this.handleChangeInput} /><br />
                <input name="description" placeholder="Description" value={this.state.description} onChange={this.handleChangeInput} /><br />
                <input name="date" placeholder="Date" value={this.state.date} onChange={this.handleChangeInput} /><br />
                <input name="id_category" placeholder="Id Category" value={this.state.id_category} onChange={this.handleChangeInput} /><br /><br />
                <button className="btn-create" onClick={this.addNewArtikel}>Create Artikel</button><br /><br />
            </div>
        );
    }
}

export default Artikel;